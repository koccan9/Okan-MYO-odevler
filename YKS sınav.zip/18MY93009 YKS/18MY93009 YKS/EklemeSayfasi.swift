//
//  EklemeSayfasi.swift
//  18MY93009 YKS
//
//  Created by ttt on 22.02.2020.
//  Copyright © 2020 ttt. All rights reserved.
//

import UIKit
import CoreData


class EklemeSayfasi: UIViewController {

    
    @IBOutlet weak var tcno: UITextField!
    
    @IBOutlet weak var isim: UITextField!
    
    @IBOutlet weak var soyisim: UITextField!
    
    @IBOutlet weak var babaAdi: UITextField!
    
    @IBOutlet weak var anneAdi: UITextField!
    
    @IBOutlet weak var yil: UITextField!
    
    @IBOutlet weak var ay: UITextField!
    
    @IBOutlet weak var gun: UITextField!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
    }
    /*private func fitToSize(){//gerek duyukalabilir hazırda bulunsun
        tcno.sizeToFit()
        isim.sizeToFit()
        soyisim.sizeToFit()
        anneAdi.sizeToFit()
        babaAdi.sizeToFit()
        yil.sizeToFit()
        ay.sizeToFit()
        gun.sizeToFit()
    }*/
    private func clearEntries(){
        tcno.text!=""
        isim.text!=""
        soyisim.text!=""
        anneAdi.text!=""
        babaAdi.text!=""
        yil.text!=""
        ay.text!=""
        gun.text!=""
    }
    @IBAction func onAdayClick(_ sender: Any, forEvent event: UIEvent) {
        if(tcno.text!.isEmpty || isim.text!.isEmpty || soyisim.text!.isEmpty
            || anneAdi.text!.isEmpty || babaAdi.text!.isEmpty ||
            yil.text!.isEmpty || ay.text!.isEmpty || gun.text!.isEmpty){
            clearEntries()
            print("girişlerde boşluklar tespit edildi")
            return
        }
        guard let _=Int(tcno.text!) else{
            print("tc kimlik hatalı")
            clearEntries()
            return
        }
        if let temp_ay=Int(ay.text!){
            if let temp_gun=Int(gun.text!){
                if(temp_ay==2){//şubat
                    if(temp_gun<=0||temp_gun>28){
                        print("hatalı şubat ayı günü")
                        clearEntries()
                        return
                    }
                }
                else if(temp_gun<=0||temp_gun>30){
                    print("hatalı ay günü")
                    clearEntries()
                    return
                }
            }
            else{
                print("tarih gün geçersiz")
                clearEntries()
                return
            }
        }
        else{
            print("tarih ay geçersiz")
            clearEntries()
            return
        }
        var aday=Aday()
        aday.anneAdi=anneAdi.text!
        aday.babaAdi=babaAdi.text!
        aday.tcno=tcno.text!
        aday.ay=ay.text!
        aday.yil=yil.text!
        aday.gun=gun.text!
        aday.isim=isim.text!
        aday.soyisim=soyisim.text!
        DB.addAday(n: aday)
        clearEntries()
        //DB.debugPrintAdayTable() //geliştirme sürecinde sadece debug amaçlı
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
