//
//  ListelemeSayfasi.swift
//  18MY93009 YKS
//
//  Created by ttt on 23.02.2020.
//  Copyright © 2020 ttt. All rights reserved.
//

import UIKit

class ListelemeSayfasi: UIViewController,UITableViewDataSource {
    let rows=DB.getAdaylar()
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        DB.getAdayCount()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel!.text=rows[indexPath.row].toString()
        return cell
    }
    

    @IBOutlet weak var adaylarList: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        adaylarList.dataSource=self
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
