//
//  ViewController.swift
//  18MY93009 YKS
//
//  Created by ttt on 22.02.2020.
//  Copyright © 2020 ttt. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

