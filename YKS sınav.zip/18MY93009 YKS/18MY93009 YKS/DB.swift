//
//  DB.swift
//  18MY93009 YKS
//
//  Created by ttt on 23.02.2020.
//  Copyright © 2020 ttt. All rights reserved.
//

import Foundation

public struct Aday{//Aday Entitiy
    init() {
        
    }
    var tcno=""
    var isim=""
    var soyisim=""
    var anneAdi=""
    var babaAdi=""
    var yil=""
    var ay=""
    var gun=""
    func toString()->String{//GUI'de görüntülensin diye
        return "TCNO:("+tcno+") isim:("+isim+") soyisim:("+soyisim+")"
    }
}

public struct DB{//veritabanım
    private init(){
        //nesnesi yaratılmayacak
    }
    private static var adaylar=[Aday]()//Aday Tablosu
    static func addAday(n:Aday){//insert sorgum
        adaylar.append(n)
    }
    static func getAdaylar()->[Aday]{//select sorgum
        return adaylar
    }
    static func getAdayCount()->Int{// select count(*) from Aday
        return adaylar.count
    }
    /*static func debugPrintAdayTable(){//geliştirme sürecinde sadece debug amaçlı
        print("DEBUG")
        for i in adaylar{
            print(i.tcno,i.isim,i.soyisim,i.anneAdi,i.babaAdi,i.yil,i.ay,i.gun)
        }
    }*/
    
}
