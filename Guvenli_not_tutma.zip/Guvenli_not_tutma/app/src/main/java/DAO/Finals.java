package DAO;

public final class Finals {//sabitlerin bulunduğu sınıf
    private Finals(){//bu sınıf türünden nesne yaratmak mantık dışı olduğu için constructor private yapılmıştır.
        
    }
    public static final String AppDatabaseName="not_uygulama_db";
    public static final String prefs="app_lock";
}
//final class'lar türetmeye kapalıdır.